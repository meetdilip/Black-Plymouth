# Ubuntu-Plymouth-Theme
Ubuntu Plymouth Theme concept. <br>
<br>
I hope this can one day be seen as a boot screen animation available for Ubuntu

![plymouth](https://i.imgur.com/BZXneYK.gif)
